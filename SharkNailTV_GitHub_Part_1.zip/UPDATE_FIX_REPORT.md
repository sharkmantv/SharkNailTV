# SharkNailTV GitHub update repair report

## Changes
- Consolidated release automation into `.github/workflows/shark-build.yml` to prevent competing releases.
- Built from the repository root, matching the included Android source tree (no external source ZIP dependency).
- Wired `SHARK_VERSION_CODE` and `SHARK_VERSION_NAME` into Android Gradle configuration.
- Generated release tags `v3.MINOR.PATCH` from the GitHub run number, consistent with the app updater's `major*10000 + minor*100 + patch` parser. Example: run 1 -> v3.0.1, versionCode 30001.
- Kept signed APK verification, certificate pinning, release asset `SharkNailTV.apk`, and update.json publishing.
- Removed the outdated build-release workflow from the package.

## Deploy
1. Copy the **contents** of this repaired project into the root of your GitHub repository, preserving `.github/workflows/shark-build.yml`.
2. Delete any existing `.github/workflows/build-release.yml` or duplicate release workflow in the repository.
3. Add GitHub Actions secrets: `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_CERT_SHA256`. The keystore must match the certificate of the app currently installed on devices. Never commit JKS files.
4. In repository Settings > Actions > General, allow GitHub Actions to create releases (read/write workflow permissions, if required by repository settings).
5. Push to `main` or run the workflow manually. Check the Actions build log and verify that a public latest GitHub release contains `SharkNailTV.apk`.
6. Open the app on Android TV with internet access; the app checks for a newer release at most once per day. Android requires user approval for installation.

## Important limitations
- This updates the Android **app**, not device operating-system firmware.
- The updater currently reads GitHub Releases API and uses the release tag; it does **not** consume update.json or verify its SHA-256. Android package signature verification remains enforced during installation.
- Version tags from this workflow are valid while run numbers are <= 9999. Existing higher versionCode installations cannot downgrade; update the scheme if your existing installed versionCode is above 30000 + run number.
- If a release tag already exists, publication fails rather than overwriting a released binary.
- The repository must be public for unauthenticated GitHub release checking.
- Source may have unrelated compile issues or missing dependencies. This environment has not compiled the APK or tested an Android TV install.
- Keystore files supplied by the user are deliberately excluded from this package; use GitHub secrets instead.
