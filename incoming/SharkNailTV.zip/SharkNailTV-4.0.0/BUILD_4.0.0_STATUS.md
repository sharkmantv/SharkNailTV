# SharkNailTV 4.0.0 — revised source candidate (not compiled)

Based on the supplied 3.4.8 source. Removed torrent engine, AIOStreams, PenguPlay and the separate Home and Shark Stream buttons. Replaced the Home discovery/poster screen with five landscape tiles for Shark TV, Movies, TV Series, Sports Guide and Settings. Shared gold focus animation; existing logo artwork retained. TMDB catalogue artwork remains for IPTV Movies and Series, with provider artwork fallback. Media3 stays at 1.11.1; no beta or IBO proprietary code added. Original app ID and landscape launcher retained. Existing OTA updater and publish workflow retained. Added a manually triggered signed test workflow that checks the certificate against the published 3.4.8 APK and produces an artifact without publishing a release.

## Build and test
Use an isolated branch, not main: the existing main push workflow can publish an OTA automatically. In GitHub Actions run Build signed SharkNailTV test APK on the test branch (workflow must first be registered on the default branch to dispatch, without pushing app source to main) or build the source using Android Studio with the existing permanent signing key. Test on TV and phone, including catalogue artwork, Sports Guide, playback, and OTA upgrade from 3.4.8. Only publish after passing.

## Limitations
Local Gradle and Android SDK are absent and dependency downloads fail DNS resolution. Kotlin syntax and YAML checks are not compilation. No signed APK, runtime device tests, measured IBO-style speed improvement, or OTA publication has been completed. Existing dormant TMDB helper functions are retained but Home discovery loading is no longer invoked. No changes to actual IPTV player code were intended. The original 3.4.8 archive is unchanged.
